package embedded.demo;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Embeddable
public class Address {

	private String line;
	public Address() {
		super();
	}
	
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public Address(int id, String line) {
		super();
		this.line = line;
	}
	
}
