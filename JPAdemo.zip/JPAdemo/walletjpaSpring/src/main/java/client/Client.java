package client;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.support.GenericXmlApplicationContext;

import beans.Customer;
import repo.WalletRepo;
import service.WalletService;
import service.WalletServiceImpl;

public class Client {
	public static void main(String[] args)
	{

		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanconfig.xml");
		WalletService service = ctx.getBean("service",WalletService.class);
		
		
		service.createAccount(1, "bharath", "9845555555", 10000);
		service.createAccount(2, "chai", "9846666666", 9000);
		service.createAccount(3, "mahi", "9847777777", 7000);
		service.createAccount(4, "akki", "9888888888", 5000);
		service.createAccount(5, "sai", "9999999999", 7000);
		
		System.out.println(service.showBalance("9846666666"));
		service.deposit("9846666666", 10000);
		// after depositing amount 
		System.out.println(service.showBalance("9846666666"));
		System.out.println();
		
		System.out.println(service.showBalance("9888888888"));
	    boolean b = service.withdraw("9888888888", 4000);
	    if(b == false)
        {
	    	System.out.println("Invalid amount");
	    }
	    
	    
	    System.out.println(service.showBalance("9888888888"));
	    
	    System.out.println(service.showBalance("9999999999"));
	    b = service.withdraw("9999999999", 9000);
	    if(b == false)
        {
	    	System.out.println("Invalid amount");
	    }
	    System.out.println(service.showBalance("9999999999"));
		}

}