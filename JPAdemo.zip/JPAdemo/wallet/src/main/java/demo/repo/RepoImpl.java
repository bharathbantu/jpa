package demo.repo;
import java.util.Map;

import javax.persistence.EntityManager;

import demo.beans.Customer;
import demo.beans.Wallet;

public class RepoImpl implements WalletRepo{
	Map<String,Customer> data;
protected EntityManager em;
	
	
	public RepoImpl(EntityManager em) {
	super();
	this.em = em;
}


	public RepoImpl(Map<String, Customer> data2) {
		// TODO Auto-generated constructor stub
	data=data2;
	}


	public boolean save(Customer c) {
		data.put(c.getMobileNumber(),c);
		
		return true;
	}


	public Customer findOne(int id) {
		
		return em.find(Customer.class, id);
	}

	
	
	

}
