package demo.repo;

import demo.beans.Customer;
import demo.beans.Wallet;

public interface WalletRepo {
	public boolean save(Customer c);
	public Customer findOne(int id);
}
