package demo.client;
/*import javax.persistence.*;
import java.util.HashMap;
import java.util.Map;
*/
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import demo.beans.Customer;

//import org.springframework.context.support.GenericXmlApplicationContext;

//import demo.beans.Customer;
import demo.beans.Wallet;
import demo.repo.RepoImpl;
import demo.repo.WalletRepo;
/*import demo.repo.WalletRepo;
import demo.repo.RepoImpl;*/
import demo.service.WalletService;
import demo.service.ServiceImpl;

public class Client {
	public static void main(String[] args) {
	/*	Map<String,Customer> data=new HashMap<>();
		WalletRepo repo=new RepoImpl(data);
		WalletService service=new ServiceImpl(repo);
*/	
		
		/*GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanconfig.xml");
    	WalletService service = ctx.getBean("service", WalletService.class);*/
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		WalletRepo repo = new RepoImpl(em);
		WalletService service = new ServiceImpl(repo, em);
		
		em.getTransaction().begin();
		//Wallet wallet1 = new Wallet(1,98568.9f);
		//Wallet wallet2 = new Wallet(2,98568.9f);
		/*service.createAccount(1, "Annapurnayya", "99887755", wallet1);
		System.out.println(service.showBalance(1));
		service.depositAmount(1, 55555f);
		System.out.println(service.showBalance(1));
		service.withDrawAmount(1, 55555f);*/
		Customer c=service.showBalance(1);
		System.out.println("Cusotmer: " +c);
		//service.createAccount("Madduri", "987654321", wallet2);
		em.getTransaction().commit();
		//service.depositAmount(1, 55555f); 
		//System.out.println(service.showBalance("99887755"));
		
		/*System.out.println(service.showBalance("99887755"));
		service.withDrawAmount("99887755", 55555f);
		System.out.println(service.showBalance("99887755"));*/
		//ctx.close();
		em.close();
		emf.close();
	}

}
