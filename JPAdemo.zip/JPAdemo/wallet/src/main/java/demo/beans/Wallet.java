package demo.beans;

import javax.persistence.*;

@Entity
public class Wallet {
	@Id private int wallet_id;
	private float balance;
	
	

	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wallet(int wallet_id, float balance) {
		super();
		this.wallet_id = wallet_id;
		this.balance = balance;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
}
