package demojpa.onetomany;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;


public class EmployeeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		EmployeeService service = new EmployeeService(em);
		

		em.getTransaction().begin();
		Address address1 = new Address(1, "TalwadeGaon,Pune");
		Address address2 = new Address(2, "dehuGaon,Pune");
		Address address3 = new Address(3, "hinjewadiGaon,Pune");
		Employee emp1 = new Employee(50948, "Sagar", 60000, address1);
		Employee emp2 = new Employee(50949,"Renu", 90000, address2);
		Employee emp3 = new Employee(50950, "Mrudula", 80000, address3);
		Employee emp4 = new Employee(50941, "aditya", 10000, address1);
		Employee emp5 = new Employee(50942,"chaitu", 20000, address2);
		Employee emp6 = new Employee(50953, "Mahidar", 30000, address3);
		Employee emp7 = new Employee(50944, "suresh", 40000, address1);
		Employee emp8 = new Employee(50945,"lohit", 50000, address2);
		Employee emp9 = new Employee(50956, "bharath", 60000, address3);
		List<Employee> empList1 = new ArrayList<Employee>();
		empList1.add(emp1);
		empList1.add(emp2);
		empList1.add(emp3);
		Department dept1 = service.createDepartment(1, "Timepass",empList1);
		List<Employee> empList2 = new ArrayList<Employee>();
		empList2.add(emp4);
		empList2.add(emp5);
		empList2.add(emp6);
		Department dept2 = service.createDepartment(2, "Research and development",empList2);
		List<Employee> empList3 = new ArrayList<Employee>();
		empList3.add(emp7);
		empList3.add(emp8);
		empList3.add(emp9);
		Department dept3 = service.createDepartment(3, "developers",empList3);
		em.getTransaction().commit();
		
		List<Employee> emps = service.findAllEmployees();
		
		for(Employee e : emps){
			System.out.println("All employees :: "+e);
		}
		em.close();
		emf.close();
	}

}

