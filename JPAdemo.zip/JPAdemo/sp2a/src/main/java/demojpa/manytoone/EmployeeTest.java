package demojpa.manytoone;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class EmployeeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		EmployeeService service = new EmployeeService(em);
		
*/
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanconfig.xml");
		EmployeeService service=ctx.getBean("service",EmployeeService.class);
		Address a=new Address(1,"talwade");
		Department d=new Department(1,"developer");
		Employee e=new Employee(1,"bharath",8000,a);
		e.setDepartment(d);
		service.createEmployee(e);

	
	}

}

