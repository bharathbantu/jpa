package demojpa.manytoone;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;


public class EmployeeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		EmployeeService service = new EmployeeService(em);
		

		em.getTransaction().begin();
		Address address1 = new Address(1, "TalwadeGaon,Pune");
		Address address2 = new Address(2, "dehuGaon,Pune");
		Address address3 = new Address(3, "hinjewadiGaon,Pune");
		Department dept1 = new Department(1, "Timepass");
		Department dept2 = new Department(2, "Research and development");
		Department dept3 = new Department(3, "developers");
		Employee emp1 = service.createEmployee(50948, "Sagar", 60000, address1, dept1);
		Employee emp2 = service.createEmployee(50949, "Renu", 90000, address2, dept2);
		Employee emp3 = service.createEmployee(50950, "Mrudula", 80000, address3, dept3);
		Employee emp4 = service.createEmployee(50941, "aditya", 10000, address1, dept1);
		Employee emp5 = service.createEmployee(50942,"chaitu", 20000, address2, dept2);
		Employee emp6 = service.createEmployee(50953, "Mahidar", 30000, address3, dept3);
		Employee emp7 = service.createEmployee(50944, "suresh", 40000, address1, dept1);
		Employee emp8 = service.createEmployee(50945,"lohit", 50000, address2, dept2);
		Employee emp9 = service.createEmployee(50956, "bharath", 60000, address3, dept3);
		em.getTransaction().commit();
		
		List<Employee> emps = service.findAllEmployees();
		
		for(Employee e : emps){
			System.out.println("All employees :: "+e);
		}
		em.close();
		emf.close();
	}

}

