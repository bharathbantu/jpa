package demo.beans;

import java.util.List;

import javax.persistence.*;

@Entity
public class Wallet {
	@Id private int wallet_id;
	private float balance;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="WALLET_ID")
	private List<Transaction> transaction;
	

	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wallet(int wallet_id, float balance) {
		super();
		this.wallet_id = wallet_id;
		this.balance = balance;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	public List<Transaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	
}
