package demo.service;

import demo.beans.Customer;




public interface WalletService {
	public  Customer createAccount(int id, String name,String mobileNumber,float amount);
	//public Customer createAccount(Customer c); 
	public  Customer showBalance(int id);
	public boolean depositAmount(int id, float depositAmount);
	public boolean withDrawAmount(int id, float withDrawAmount);

}
