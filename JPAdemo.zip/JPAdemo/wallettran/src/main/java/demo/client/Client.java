package demo.client;
import org.springframework.context.support.GenericXmlApplicationContext;

import demo.service.WalletService;

public class Client {
	public static void main(String[] args) {
	
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanconfig.xml");
    	WalletService service = ctx.getBean("service", WalletService.class);
		
		
		
		service.createAccount(1,"9876543219","adi",1000);
		service.createAccount(2,"9876543219","asd",2000);
		service.createAccount(3,"9876543219","qwe",4000);
		service.createAccount(4,"9876543219","zxc",5000);
		service.createAccount(5,"9876543219","rty",5000);
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		service.depositAmount(1, 100);
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		service.depositAmount(1, 100);
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		service.depositAmount(1, 100);
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		service.depositAmount(1, 100);
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		service.depositAmount(1, 100);
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		/*boolean b = service.withDrawAmount(1, 100000);
		if(b==true)
		System.out.println("Customer [ "+service.showBalance(1)+" ]");
		else
			System.out.println("balance is low");*/
		ctx.close();
	}

}
