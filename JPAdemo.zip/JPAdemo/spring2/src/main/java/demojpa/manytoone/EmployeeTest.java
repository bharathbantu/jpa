package demojpa.manytoone;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.springframework.context.support.GenericApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


public class EmployeeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		
		EntityManager em = emf.createEntityManager();
		EmployeeService service = new EmployeeService(em);
		
*/
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext("beanconfig.xml");
		EmployeeService service=ctx.getBean("serv",EmployeeService.class);
		/*em.getTransaction().begin();*/
		Address address1 = new Address( 1,"TalwadeGaon,Pune");
		Address address2 = new Address(2, "dehuGaon,Pune");
		Address address3 = new Address(3, "hinjewadiGaon,Pune");
		Address address4 = new Address(4, "hiadiGaon,Pune");
		Department dept1 = new Department(7, "Timepass");
		Department dept2 = new Department(5, "Research and development");
		Department dept3 = new Department(6, "developers");
		Employee emp1 = service.createEmployee(91948, "bharath", 60000, address1, dept1);
		Employee emp2 = service.createEmployee(91949, "chai", 90000, address2, dept2);
		Employee emp3 = service.createEmployee(91950, "akhi", 80000, address3, dept3);
		Employee emp4 = service.createEmployee(91980, "baba", 80000, address4, dept3);
		
		/*em.getTransaction().commit();*/
		
		List<Employee> emps = service.findAllEmployees();
		
		for(Employee e : emps){
			System.out.println("All employees :: "+e);
		}
		/*em.close();
		emf.close();*/
	}

}

